# Japan-Weather-Outcomes
 Created Regression Linear Models for Japan Weather 2010-2019 that includes outcomes for total precipitation, mean air temperature, mean relative humidity, percentage possible sunshine, total sunshine duration, solar radiation, & mean wind speed
